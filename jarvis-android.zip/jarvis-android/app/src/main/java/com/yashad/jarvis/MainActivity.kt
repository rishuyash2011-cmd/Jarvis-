package com.yashad.jarvis

import android.Manifest
import android.app.Activity
import android.content.ContentUris
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.text.InputType
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.net.UnknownHostException
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.Executors

private const val NAME = "Yashad"
private const val DEFAULT_MODEL = "claude-sonnet-5-5"

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var prefs: SharedPreferences
    private lateinit var tts: TextToSpeech
    private var ttsReady = false

    private lateinit var logView: TextView
    private lateinit var scroll: ScrollView
    private lateinit var statusView: TextView
    private lateinit var input: EditText

    private val io = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())
    private val history = mutableListOf<Pair<String, String>>()
    private var busy = false

    private val speechLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val heard = result.data
                    ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                    ?.firstOrNull()
                if (!heard.isNullOrBlank()) {
                    handle(heard)
                    return@registerForActivityResult
                }
            }
            setStatus("Standing by")
        }

    private val calendarPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            sendBriefing(granted)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("jarvis", MODE_PRIVATE)
        tts = TextToSpeech(this, this)

        logView = findViewById(R.id.log)
        scroll = findViewById(R.id.scroll)
        statusView = findViewById(R.id.status)
        input = findViewById(R.id.input)

        findViewById<View>(R.id.orb).setOnClickListener { listen() }
        findViewById<View>(R.id.send).setOnClickListener { submitInput() }
        findViewById<View>(R.id.settings).setOnClickListener { showSettings() }
        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                submitInput()
                true
            } else {
                false
            }
        }

        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val greeting = when {
            hour < 5 -> "Good evening"
            hour < 12 -> "Good morning"
            hour < 17 -> "Good afternoon"
            else -> "Good evening"
        }
        if (apiKey().isBlank()) {
            addLog("Jarvis", "$greeting, $NAME. Open Settings and paste your Anthropic API key to begin.")
        } else {
            addLog("Jarvis", "$greeting, $NAME. Tap the orb and speak, or type a command.")
            if (savedInstanceState == null && prefs.getBoolean("listen_on_open", true)) {
                ui.postDelayed({ listen() }, 700)
            }
        }
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (apiKey().isNotBlank() && prefs.getBoolean("listen_on_open", true)) listen()
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale("en", "IN")
            ttsReady = true
        }
    }

    override fun onDestroy() {
        tts.shutdown()
        io.shutdown()
        super.onDestroy()
    }

    // ---------- UI helpers ----------

    private fun setStatus(text: String) {
        statusView.text = text.uppercase(Locale.getDefault())
    }

    private fun addLog(who: String, text: String) {
        logView.append("$who\n$text\n\n")
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun reply(text: String) {
        addLog("Jarvis", text)
        if (ttsReady && prefs.getBoolean("voice", true)) {
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
        }
    }

    private fun submitInput() {
        val t = input.text.toString().trim()
        if (t.isNotEmpty()) {
            input.setText("")
            handle(t)
        }
    }

    private fun apiKey(): String = prefs.getString("api_key", "")?.trim().orEmpty()

    private fun model(): String =
        prefs.getString("model", DEFAULT_MODEL).orEmpty().ifBlank { DEFAULT_MODEL }

    private fun showSettings() {
        val pad = (20 * resources.displayMetrics.density).toInt()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad / 2, pad, 0)
        }
        val keyField = EditText(this).apply {
            hint = "Anthropic API key (sk-ant-...)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(apiKey())
        }
        val modelField = EditText(this).apply {
            hint = "Model"
            setText(model())
        }
        val listenBox = CheckBox(this).apply {
            text = "Start listening when the app opens"
            isChecked = prefs.getBoolean("listen_on_open", true)
        }
        val voiceBox = CheckBox(this).apply {
            text = "Speak replies aloud"
            isChecked = prefs.getBoolean("voice", true)
        }
        box.addView(keyField)
        box.addView(modelField)
        box.addView(listenBox)
        box.addView(voiceBox)

        AlertDialog.Builder(this)
            .setTitle("Settings")
            .setView(box)
            .setPositiveButton("Save") { _, _ ->
                prefs.edit()
                    .putString("api_key", keyField.text.toString().trim())
                    .putString("model", modelField.text.toString().trim())
                    .putBoolean("listen_on_open", listenBox.isChecked)
                    .putBoolean("voice", voiceBox.isChecked)
                    .apply()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---------- voice in ----------

    private fun listen() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
            .putExtra(RecognizerIntent.EXTRA_PROMPT, "Listening")
        try {
            setStatus("Listening")
            speechLauncher.launch(intent)
        } catch (e: Exception) {
            setStatus("Standing by")
            reply("Speech recognition is not available on this phone. Type your command instead.")
        }
    }

    // ---------- commands ----------

    private fun handle(cmd: String) {
        if (busy) return
        addLog("You", cmd)
        val key = apiKey()
        if (key.isBlank()) {
            reply("Add your Anthropic API key in Settings first.")
            showSettings()
            return
        }
        val briefing = Regex(
            "^(good morning|morning briefing|brief me|daily briefing)",
            RegexOption.IGNORE_CASE
        )
        if (briefing.containsMatchIn(cmd.trim())) {
            startBriefing()
            return
        }

        busy = true
        setStatus("Thinking")
        io.execute {
            try {
                val msgs = history.takeLast(6).toMutableList()
                msgs.add("user" to cmd)
                val raw = ClaudeClient.send(key, model(), systemPrompt(), msgs)
                ui.post { onModelReply(cmd, raw) }
            } catch (e: Exception) {
                ui.post {
                    busy = false
                    setStatus("Standing by")
                    reply(friendlyError(e))
                }
            }
        }
    }

    private fun onModelReply(cmd: String, raw: String) {
        busy = false
        setStatus("Standing by")
        var say = raw.trim()
        var action: JSONObject? = null
        try {
            val s = raw.indexOf('{')
            val e = raw.lastIndexOf('}')
            if (s >= 0 && e > s) {
                val j = JSONObject(raw.substring(s, e + 1))
                say = j.optString("say", say)
                action = j.optJSONObject("action")
            }
        } catch (e: Exception) {
            // Keep the raw text as the spoken reply.
        }
        history.add("user" to cmd)
        history.add("assistant" to raw)
        reply(if (say.isBlank()) "Done." else say)
        val act = action
        if (act != null) ui.postDelayed({ perform(act) }, 1400)
    }

    private fun perform(a: JSONObject) {
        when (a.optString("type")) {
            "open_app" -> {
                val name = a.optString("name")
                if (!openApp(name)) reply("I could not find an app called $name on this phone.")
            }
            "timer" -> launch(
                Intent(AlarmClock.ACTION_SET_TIMER)
                    .putExtra(AlarmClock.EXTRA_LENGTH, a.optInt("seconds", 60))
                    .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label", "Timer"))
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true),
                "I could not set a timer on this phone."
            )
            "alarm" -> launch(
                Intent(AlarmClock.ACTION_SET_ALARM)
                    .putExtra(AlarmClock.EXTRA_HOUR, a.optInt("hour", 7))
                    .putExtra(AlarmClock.EXTRA_MINUTES, a.optInt("minute", 0))
                    .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label", "Alarm"))
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true),
                "I could not set an alarm on this phone."
            )
            "dial" -> {
                val number = a.optString("number").filter { it.isDigit() || it == '+' }
                launch(
                    Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")),
                    "I could not open the dialer."
                )
            }
            "whatsapp" -> {
                val number = a.optString("number").filter { it.isDigit() }
                val text = Uri.encode(a.optString("text"))
                launch(
                    Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$number?text=$text")),
                    "I could not open WhatsApp."
                )
            }
            "web" -> {
                val url = a.optString("url")
                if (url.startsWith("https://")) {
                    launch(Intent(Intent.ACTION_VIEW, Uri.parse(url)), "I could not open that link.")
                }
            }
            "search" -> launch(
                Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("https://www.google.com/search?q=" + Uri.encode(a.optString("query")))
                ),
                "I could not open the search."
            )
            "maps" -> launch(
                Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse(
                        "https://www.google.com/maps/search/?api=1&query=" +
                            Uri.encode(a.optString("query"))
                    )
                ),
                "I could not open Maps."
            )
            "calendar" -> {
                val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
                val start = try {
                    fmt.parse(a.optString("start"))?.time
                } catch (e: Exception) {
                    null
                }
                val i = Intent(Intent.ACTION_INSERT)
                    .setData(CalendarContract.Events.CONTENT_URI)
                    .putExtra(CalendarContract.Events.TITLE, a.optString("title", "Event"))
                if (start != null) {
                    i.putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, start)
                    i.putExtra(
                        CalendarContract.EXTRA_EVENT_END_TIME,
                        start + a.optInt("minutes", 60) * 60000L
                    )
                }
                launch(i, "I could not open the calendar.")
            }
        }
    }

    private fun launch(intent: Intent, failMessage: String) {
        try {
            startActivity(intent)
        } catch (e: Exception) {
            reply(failMessage)
        }
    }

    private fun openApp(name: String): Boolean {
        val q = name.lowercase(Locale.getDefault()).trim()
        if (q.isEmpty()) return false
        val pm = packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(main, 0)
        val match = apps.firstOrNull {
            it.loadLabel(pm).toString().lowercase(Locale.getDefault()) == q
        } ?: apps.firstOrNull {
            it.loadLabel(pm).toString().lowercase(Locale.getDefault()).contains(q)
        } ?: return false
        val launchIntent = pm.getLaunchIntentForPackage(match.activityInfo.packageName) ?: return false
        return try {
            startActivity(launchIntent)
            true
        } catch (e: Exception) {
            false
        }
    }

    // ---------- morning briefing ----------

    private fun startBriefing() {
        val granted = ContextCompat.checkSelfPermission(
            this, Manifest.permission.READ_CALENDAR
        ) == PackageManager.PERMISSION_GRANTED
        if (granted) sendBriefing(true) else calendarPermission.launch(Manifest.permission.READ_CALENDAR)
    }

    private fun sendBriefing(calendarGranted: Boolean) {
        if (busy) return
        busy = true
        setStatus("Preparing briefing")
        val key = apiKey()
        io.execute {
            try {
                val events = if (calendarGranted) todaysEvents() else null
                val date = SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(Date())
                val prompt = buildString {
                    append("Today is ").append(date).append(".\n")
                    if (events == null) {
                        append("Calendar access was not granted, so you cannot see today's events.\n")
                    } else if (events.isEmpty()) {
                        append("The calendar shows no events today.\n")
                    } else {
                        append("Today's calendar events:\n")
                        events.forEach { append("- ").append(it).append("\n") }
                    }
                }
                val system = "You are Jarvis giving $NAME a spoken morning briefing. " +
                    "Write 4 to 6 short sentences, warm and direct, with no markdown and no lists. " +
                    "Greet them, state the date, summarise the calendar events in time order, " +
                    "and end with one line of encouragement. Never invent events, weather or news."
                val text = ClaudeClient.send(key, model(), system, listOf("user" to prompt), 500)
                ui.post {
                    busy = false
                    setStatus("Standing by")
                    reply(text.trim())
                }
            } catch (e: Exception) {
                ui.post {
                    busy = false
                    setStatus("Standing by")
                    reply(friendlyError(e))
                }
            }
        }
    }

    private fun todaysEvents(): List<String> {
        val out = mutableListOf<String>()
        try {
            val cal = Calendar.getInstance()
            cal.set(Calendar.HOUR_OF_DAY, 0)
            cal.set(Calendar.MINUTE, 0)
            cal.set(Calendar.SECOND, 0)
            cal.set(Calendar.MILLISECOND, 0)
            val start = cal.timeInMillis
            val end = start + 24L * 3600L * 1000L
            val builder = CalendarContract.Instances.CONTENT_URI.buildUpon()
            ContentUris.appendId(builder, start)
            ContentUris.appendId(builder, end)
            val cursor = contentResolver.query(
                builder.build(),
                arrayOf(
                    CalendarContract.Instances.TITLE,
                    CalendarContract.Instances.BEGIN,
                    CalendarContract.Instances.ALL_DAY
                ),
                null,
                null,
                CalendarContract.Instances.BEGIN + " ASC"
            )
            val timeFmt = SimpleDateFormat("h:mm a", Locale.getDefault())
            cursor?.use {
                while (it.moveToNext()) {
                    val title = it.getString(0) ?: "Event"
                    val begin = it.getLong(1)
                    val allDay = it.getInt(2) == 1
                    out.add(if (allDay) "$title (all day)" else timeFmt.format(Date(begin)) + " " + title)
                }
            }
        } catch (e: Exception) {
            // No calendar available; return what we have.
        }
        return out
    }

    // ---------- prompts and errors ----------

    private fun systemPrompt(): String {
        val now = SimpleDateFormat("EEEE, d MMMM yyyy, h:mm a", Locale.getDefault()).format(Date())
        return """
You are Jarvis, a calm, concise voice assistant on ${NAME}'s Android phone. Now: $now (${TimeZone.getDefault().id}).
Reply in at most three short sentences that sound natural when read aloud. Never claim to see messages, notifications, calendar or weather unless they are given to you.
You can ask the phone to do ONE thing per reply by including an action. Respond with ONLY a JSON object, no markdown:
{"say": string, "action": null or one of
{"type":"open_app","name":"app name as shown on the phone"}
{"type":"timer","seconds":number,"label":string}
{"type":"alarm","hour":0-23,"minute":0-59,"label":string}
{"type":"dial","number":string}
{"type":"whatsapp","number":"digits with country code","text":string}
{"type":"web","url":"https://..."}
{"type":"search","query":string}
{"type":"maps","query":string}
{"type":"calendar","title":string,"start":"yyyy-MM-dd HH:mm","minutes":number}}
Only use an action when the person asks for it. If you lack a detail such as a phone number, ask for it and use null as the action.
""".trimIndent()
    }

    private fun friendlyError(e: Exception): String {
        val m = e.message.orEmpty()
        return when {
            e is UnknownHostException -> "I cannot reach the internet right now."
            m.contains("HTTP 401") -> "Your API key was rejected. Check it in Settings."
            m.contains("HTTP 429") -> "I am being rate limited. Try again in a moment."
            m.contains("credit", ignoreCase = true) -> "Your Anthropic API account needs credits."
            m.contains("HTTP 404") -> "That model name was not found. Check it in Settings."
            else -> "Something went wrong. Try again in a moment."
        }
    }
}
