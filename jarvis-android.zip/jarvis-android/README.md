# Jarvis for Android

A voice assistant app. Speak or type a command; Claude works out what you mean and the app carries it out on your phone.

## Build the APK (about 15 minutes the first time)

1. Install Android Studio (free): https://developer.android.com/studio
2. Unzip this folder. In Android Studio choose File > Open and pick the `jarvis-android` folder.
3. Wait for "Gradle sync" to finish (first run downloads tools, so keep Wi-Fi on).
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Click "locate" in the popup. The file is `app/build/outputs/apk/debug/app-debug.apk`.
6. Send that APK to your phone (Google Drive, WhatsApp to yourself, or a USB cable).
7. On the phone, open the APK and allow "Install unknown apps" for the app you opened it from.

Or plug in your phone with USB debugging on and press the green Run button.

## First run

1. Open Jarvis and tap SETTINGS.
2. Paste an Anthropic API key (create one at https://console.anthropic.com, add a few dollars of credit). This is separate from the Claude app subscription.
3. Tap the orb and speak.

## What you can say

- "Open WhatsApp" / "open Gmail" / any installed app by its name
- "Set a timer for 10 minutes" / "wake me at 6:30"
- "Good morning" (spoken briefing from today's calendar, asks for calendar permission once)
- "Add a meeting with Ravi tomorrow at 11" (opens the calendar form filled in)
- "Navigate to Gandhipuram" / "search for textile export duty" / "call 98xxxxxxxx"
- "Message 91XXXXXXXXXX on WhatsApp saying I will call you at 5" (opens the chat with the text ready; you tap send)
- Anything else: answers, drafts, planning.

## Voice trigger

Turn on "Start listening when the app opens" in Settings, then say "Hey Google, open Jarvis". The app opens and starts listening straight away. You can also put the Jarvis icon on your home screen or a launcher shortcut.

## Limits

- No always-on "Hey Jarvis" wake word. That needs a background service and a wake-word engine; ask if you want it added.
- It cannot read your WhatsApp or SMS messages, notifications or screen.
- WhatsApp, calls and calendar events open ready-to-go and you confirm with one tap.
- The API key is stored in the app's private storage on your phone, not encrypted. Use a key with a spending limit.
- Each command is a paid API call (a few paise each).
